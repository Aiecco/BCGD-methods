Tanner Aaron Graves - 2073559
Alisa Snezskaia - 2107497
Alessandro Pala - 2107800
Anna Glado - 2122285

Main code notebook: "ODS_Homework_IPYNB.ipynb"
Supplemental code notebook: "supplementary_analysis.ipynb"

Presentation file: "Optimization Homework.pdf"

Data.zip contains the png files of the plots and the files necessary to run the LaTeX that generates the PDF presentations.